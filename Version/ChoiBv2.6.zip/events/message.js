const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = (client, message, error) => {
	const msg = message;
	try {
		const erreb = new Discord.MessageEmbed()
			.setColor(client.color.error)
			.setTitle(`${client.emote.error} | System Error`)
			.setTimestamp()
			.setFooter('By Rutheon#6205');

		if (message.author.bot) return;

		if (message.channel.type === 'dm') {
			let dmmsg = new Discord.MessageEmbed()
				.setColor(client.color.bot)
				.setTitle(`${message.author.tag}`)
				.setDescription(`MID: ${msg.id} \nAID: ${msg.author.id}`)
				.addField(
					`메시지`,
					`${msg.content || '확인 불가 (지원되지 않는 형식)'}`,
					true
				)
				.setTimestamp()
				.setFooter(
					message.author.id,
					message.author.avatarURL({ dynamic: true, format: 'jpg', size: 2048 })
				);
			return client.channels.cache.get(client.log.dmlog).send(dmmsg);
		}

		if (message.content.startsWith(client.config.prefix)) {
			if (!message.guild.me.hasPermission(['ADMINISTRATOR'])) {
				erreb.setDescription(
					`봇 작동을 위한 최빈이의 권한이 부족합니다!\nMissing Permission: ADMINISTRATOR`
				);
				return message.channel.send(erreb);
			}
		}

		const prefix = client.config.prefix;

		if (message.content.indexOf(prefix) !== 0) return;

		const args = message.content
			.slice(prefix.length)
			.trim()
			.split(/ +/g);
		const command = args.shift().toLowerCase();
		const cmd =
			client.commands.get(command) ||
			client.commands.find(cmd => cmd.aliases && cmd.aliases.includes(command));

		if (cmd) cmd.execute(client, message, args);

		if (error) {
			erreb.setDescription(error);
			return client.channels.cache.get(client.log.error).send(erreb);
		}
	} catch (e) {
		client.errI(`에러: ${e}`, msg.channel);
		client.errI(
			`명령어: ${cmd || '알수없음'}\n에러: ${e}`,
			client.channels.cache.get(client.log.error)
		);
		return;
	}
};
