module.exports = {
	bot: '#00EBF4',
	red: '#FF0000',
	blue: '#0074FF',
	success: '#00FF13',
	error: '#FF0000',
	delog: '#FF7070',
	edtlog: '#FFC862',
	imglog: '#62FFBB'
};