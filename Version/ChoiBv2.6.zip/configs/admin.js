module.exports = {
	author: '667108076561629205' //체온
};