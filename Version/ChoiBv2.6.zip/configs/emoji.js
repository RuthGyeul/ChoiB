module.exports = {
	off: '❌',
	error: '⚠️',
	success: '✅',
	ester: '❓',
	dice: '🎲',
	hourglass: '⏳',
	clock: '⏱',
	connection: '📡',
	love: '💕',
	script: '📝',
	power: '⚡️',
	star: '⭐️',
	fire: '🔥',
	sad: '😥',
	cute_hiD: '<:cute_hi:853906009608290305>',
	emoji_38: '<:emoji_38:800660915158122497>'
};
