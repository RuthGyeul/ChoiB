module.exports = {
	author: '667108076561629205',
	token: 'Nzk4MzkxNjAyNDAwOTg1MDk4.X_0WHw.Xm0Ec0PP_Gq4K3yaw8-GO9U86Fw',
	purl:
		'https://builder.pingpong.us/api/builder/603825b5e4b078d873a0a451/integration/v0.2/custom/{sessionId}',
	ptoken: 'Basic a2V5OmZiZGE2YmZkZTMxNjk5N2E0OGRiN2ZkOWRiMTUxYjU1',
	prefix: ';',
	activity: ['업데이트 80% 진행', '니 인생 생각', '니 성적 관찰', ';help']
};
