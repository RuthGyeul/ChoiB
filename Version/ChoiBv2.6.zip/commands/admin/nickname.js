const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'nickname',
	aliases: ['nn', 'nick', 'name'],
	category: 'Admin',
	description: 'Change user`s nickname',
	utilisation: '{prefix}nickname',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (msg.member.hasPermission(['MANAGE_NICKNAMES' || 'ADMINISTRATOR'])) {
				let cnMember = message.mentions.users.first();

				if (!cnMember)
					return msg.lineReply(
						`${client.emote.error} 닉넴 변경 대상자가 없습니다!`
					);

				if (
					!msg.guild.me.hasPermission(['MANAGE_NICKNAMES' || 'ADMINISTRATOR'])
				)
					return msg.lineReply(
						`${
							client.emote.error
						} 닉넴 변경을 진행할 최빈이의 권한이 부족합니다!`
					);

				let newn = cmd.slice(cnMember);

				if (!newn)
					return msg.lineReply(
						`${client.emote.error} 변경할 닉넴이 없습니다! ${newn[1]}`
					);

				msg.channel.messages.fetch({ limit: 1 }).then(messages => {
					msg.channel.bulkDelete(messages);
				});

				if (cnMember == msg.guild.me) {
					message.guild.me.setNickname(newn);
				} else if (cnMember == msg.author) {
					msg.author.setNickname(newn);
				} else {
					cnMember.setNickname(newn);
				}
			} else {
				msg.lineReply(`${client.emote.error} 넌 권한이 없습니다!`);
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
