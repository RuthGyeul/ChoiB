const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'clean',
	aliases: ['청소', '삭제', 'clean', 'delate'],
	category: 'Admin',
	description: 'Delate message 3 ~ 99',
	utilisation: '{prefix}clean <Number>',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (!msg.guild.me.hasPermission(['MANAGE_MESSAGES' || 'ADMINISTRATOR']))
				return msg.lineReply(
					`${client.emote.error} 삭제를 진행할 최빈이의 권한이 부족합니다!`
				);

			if (msg.member.hasPermission(['MANAGE_MESSAGES' || 'ADMINISTRATOR'])) {
				var argument = cmd.split(/\s+/);
				var clean = Number(argument[1]);
				if (Number(clean) == 'NAN') {
					let notnumber = new Discord.MessageEmbed()
						.setColor(client.color.error)
						.setTitle(`${client.emote.error} | Error!`)
						.setDescription('삭제할 메시지 개수를 입력해주세요!')
						.setTimestamp()
						.setFooter(
							msg.author.tag,
							msg.author.avatarURL({ dynamic: true, format: 'jpg', size: 2048 })
						);

					msg.channel.send(notnumber);
					return;
				}

				if (clean > 100 || clean < 2) {
					let impossible = new Discord.MessageEmbed()
						.setColor(client.color.error)
						.setTitle(`${client.emote.error} | Error!`)
						.setDescription('한 번에 3 ~ 99개의 메시지만 삭제가 가능합니다.')
						.setTimestamp()
						.setFooter(
							msg.author.tag,
							msg.author.avatarURL({
								dynamic: true,
								format: 'jpg',
								size: 2048
							})
						);

					msg.channel.send(impossible);
					return;
				}

				if (clean <= 99 && clean >= 3) {
					msg.channel.messages.fetch({ limit: clean }).then(messages => {
						msg.channel.bulkDelete(messages);
					});
					let cleancompletembed = new Discord.MessageEmbed()
						.setColor(client.color.success)
						.setTitle(`${client.emote.success} | Success!`)
						.setDescription(argument[1] + '개의 메세지 삭제가 완료되었습니다!')
						.setTimestamp()
						.setFooter(
							msg.author.tag,
							msg.author.avatarURL({
								dynamic: true,
								format: 'jpg',
								size: 2048
							})
						);

					msg.channel.send(cleancompletembed);
				} else {
					msg.lineReply(`${client.emote.error} 알 수 없는 에러 발생!`);
				}
			} else {
				msg.lineReply(`${client.emote.error} 넌 권한이 없습니다!`);
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
