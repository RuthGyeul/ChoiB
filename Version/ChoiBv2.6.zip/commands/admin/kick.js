const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'kick',
	aliases: ['강퇴', '추방', '임포!!', 'k', 'kick'],
	category: 'Admin',
	description: 'Kick member with reason/imposter message',
	utilisation: '{prefix}kick <@user> <reason>',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (msg.member.hasPermission(['KICK_MEMBERS' || 'ADMINISTRATOR'])) {
				let kickMember = message.mentions.members.first();

				if (!kickMember)
					return msg.lineReply(`${client.emote.error} 강퇴 대상자가 없습니다!`);

				if (!msg.guild.me.hasPermission(['KICK_MEMBERS' || 'ADMINISTRATOR']))
					return msg.lineReply(
						`${client.emote.error} 강퇴를 진행할 최빈이의 권한이 부족합니다!`
					);

				if (kickMember == msg.guild.me)
					return msg.lineReply(
						`${client.emote.error} 난 절대 여기서 나가지 않습니다.`
					);

				if (kickMember.hasPermission(['ADMINISTRATOR']))
					return msg.lineReply(
						`${client.emote.error} 내가 이 분을 감히 내보낼 수는 없습니다!`
					);

				let argument = cmd.split(kickMember);
				var reason = argument[1];

				if (!reason) {
					var reason =
						'해당 유저의 부적절한 행동이 감지되어 운영진 사전 허가에 의해 본 서버 보호 목적으로 자동 강퇴를 진행합니다.';
				}

				try {
					try {
						const kmsg = new Discord.MessageEmbed()
							.setTitle(`***${message.guild.name}에서 강퇴를 당했습니다.***`)
							.setDescription(`${reason}`)
							.setColor(client.color.error)
							.setTimestamp()
							.setFooter(`Time Stamp`);

						msg.channel.messages.fetch({ limit: 1 }).then(messages => {
							msg.channel.bulkDelete(messages);
						});

						kickMember.send(kmsg);
					} catch (e) {
						client.errI(`에러: ${e}`, msg.channel);
						client.errI(
							`명령어: ${cmd}\n에러: ${e}`,
							client.channels.cache.get(client.log.error)
						);
						return;
					}
					kickMember.kick();
					msg.channel.send(
						`.      　。　　　　•　    　ﾟ　　。\n　　.　　　.　　　  　　.　　　　　。　　   。　.\n 　.　　      。　        ඞ   。　    .    •\n • **${msg.guild.member(
							kickMember.user
						).nickname ||
							kickMember.username ||
							'누군가'}**(이)가 강퇴되었습니다. 　 。　.\n　 　　。　　　　　　ﾟ　　　.　　　　　.\n,　　　　.　 .　　       .               。`
					);
				} catch (e) {
					client.errI(`에러: ${e}`, msg.channel);
					client.errI(
						`명령어: ${cmd}\n에러: ${e}`,
						client.channels.cache.get(client.log.error)
					);
					return;
				}
			} else {
				msg.lineReply(`${client.emote.error} 넌 권한이 없습니다!`);
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
