const Discord = require('discord.js');
const novelCovid = require('novelcovid');
const moment = require('moment');
const client = new Discord.Client();

const cbData = client.cb19;

const formatNumber = number =>
	String(number).replace(/(.)(?=(\d{3})+$)/g, '$1,');

module.exports = {
	name: 'c19vaccine',
	aliases: ['c19vc', 'cvaccine', 'vc', 'cvc', '코로나백신정보'],
	category: 'Info',
	description: 'Show Covid19 vaccine status',
	utilisation: '{prefix}c19vaccine <country name/code>',

	async execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;
		try {
			const track = novelCovid;

			if (!args[0]) {
				var countryA = 'usa';
				var cdataC = await track.vaccine.countries({
					country: countryA
				});

				msg.reply(cdataC);
				console.log(cdataC);
			} else if (args[0]) {
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
