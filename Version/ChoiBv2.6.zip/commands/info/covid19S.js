const Discord = require('discord.js');
const novelCovid = require('novelcovid');
const moment = require('moment');
const client = new Discord.Client();

const cbData = client.cb19;

const formatNumber = number =>
	String(number).replace(/(.)(?=(\d{3})+$)/g, '$1,');

module.exports = {
	name: 'covid19',
	aliases: ['c19', 'corona', 'covid', '코로나정보'],
	category: 'Info',
	description: 'Show Covid19 status',
	utilisation: '{prefix}covid19 <country name/code>',

	async execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;
		try {
			const track = novelCovid;

			if (!args[0]) {
				let cdataA = await track.all();
				let yesterdaycdataA = await novelCovid.yesterday.all();
				if (cdataA.message || yesterdaycdataA.message)
					return await message.channel.send(
						cdataA.message || yesterdaycdataA.message
					);
				cdataA.todayActives = cdataA.active - yesterdaycdataA.active;
				cdataA.todayRecovereds = cdataA.recovered - yesterdaycdataA.recovered;
				cdataA.todayTests = cdataA.tests - yesterdaycdataA.tests;
				let covid19A = new Discord.MessageEmbed()
					.setTitle(`😷 전세계 코로나 현황`)
					.setColor('#00EBF4')
					.setDescription(`실제 수치와 미미한 차이가 있을 수 있습니다.`)
					.addFields(
						{
							name: 'Total Cases',
							value: cdataA.cases.toLocaleString(),
							inline: true
						},
						{
							name: 'Total Deaths',
							value: cdataA.deaths.toLocaleString(),
							inline: true
						},
						{
							name: 'Total Recovered',
							value: cdataA.recovered.toLocaleString(),
							inline: true
						},
						{
							name: "Today's Cases",
							value: cdataA.todayCases.toLocaleString(),
							inline: true
						},
						{
							name: "Today's Deaths",
							value: cdataA.todayDeaths.toLocaleString(),
							inline: true
						},
						{
							name: 'Active Cases',
							value: cdataA.active.toLocaleString(),
							inline: true
						},
						{
							name: 'Tests',
							value: `${formatNumber(cdataA.tests)}\n(${(cdataA.todayTests >= 0
								? '+'
								: '-') +
								String(Math.abs(cdataA.todayTests)).replace(
									/(.)(?=(\d{3})+$)/g,
									'$1,'
								)})`,
							inline: true
						},
						{
							name: 'Infection Rate',
							value: `${(cdataA.casesPerOneMillion / 10000).toFixed(4)} %`,
							inline: true
						},
						{
							name: 'Recovery Rate',
							value: `${((cdataA.recovered / cdataA.cases) * 100).toFixed(
								4
							)} %`,
							inline: true
						},
						{
							name: 'Population',
							value: formatNumber(cdataA.population),
							inline: true
						},
						{
							name: 'Last Updated',
							value: moment(cdataA.updated).fromNow(),
							inline: true
						}
					)
					.setTimestamp()
					.setFooter(
						message.author.tag,
						message.author.avatarURL({
							dynamic: true,
							format: 'jpg',
							size: 2048
						})
					);

				msg.channel.send(covid19A);
				return;
			}

			if (
				args[0] === 'leaderboard' ||
				args[0] === 'ld' ||
				args[0] === 'l' ||
				args[0] === '순위'
			) {
				try {
					let typeA = args[1];
					let allData = await track.all();
					let sorter = args[1] || 'cases';
					let ctrA = await track.all({ sort: typeA });
					let leaderboard = (await track.countries({ sort: sorter })).splice(
						0,
						10
					);

					let covid19L = new Discord.MessageEmbed()
						.setTitle(
							`🏅 Top 10 countries sorted by: ${sorter.charAt(0).toUpperCase() +
								sorter.slice(1)}`
						)
						.setColor(client.color.bot)
						.setDescription(
							leaderboard
								.map(
									(c, index) =>
										`**${++index}**. ${c.country} \u279C ${c[
											sorter
										].toLocaleString()} ( ${
											sorter.includes('PerOneMillion')
												? String(c[sorter]).replace(/(.)(?=(\d{3})+$)/g, '$1,')
												: ((c[sorter] / allData[sorter]) * 100).toFixed(2) + '%'
										} )`
								)
								.join('\n')
						)
						.setTimestamp()
						.setFooter(
							message.author.tag,
							message.author.avatarURL({
								dynamic: true,
								format: 'jpg',
								size: 2048
							})
						);

					msg.channel.send(covid19L);
					return;
				} catch (e) {
					client.errI(`에러: ${e}`, msg.channel);
					client.errI(
						`명령어: ${cmd}\n에러: ${e}`,
						client.channels.cache.get(client.log.error)
					);
					return;
				}
			} else if (args[0] === 'ust' || args[0] === 'state') {
				try {
					const stateData = await track.states({ state: args[1] });
					const yesterdayStateData = await track.yesterday.states({
						state: args[1]
					});
					if (stateData.message || yesterdayStateData.message)
						return await message.channel.send(
							stateData.message || yesterdayStateData.message
						);
					stateData.todayActives = stateData.active - yesterdayStateData.active;
					stateData.todayTests = stateData.tests - yesterdayStateData.tests;

					let covid19ST = new Discord.MessageEmbed()
						.setTitle(`Covid 19: ${stateData.state}, USA`)
						.setColor('#00EBF4')
						.setDescription(`실제 수치와 미미한 차이가 있을 수 있습니다.`)
						.addFields(
							{
								name: 'Cases',
								value: `${formatNumber(
									stateData.cases
								)}\n(${(stateData.todayCases >= 0 ? '+' : '-') +
									String(Math.abs(stateData.todayCases)).replace(
										/(.)(?=(\d{3})+$)/g,
										'$1,'
									)})`,
								inline: true
							},
							{
								name: 'Deaths',
								value: `${formatNumber(
									stateData.deaths
								)}\n(${(stateData.todayDeaths >= 0 ? '+' : '-') +
									String(Math.abs(stateData.todayDeaths)).replace(
										/(.)(?=(\d{3})+$)/g,
										'$1,'
									)})`,
								inline: true
							},
							{
								name: 'Active',
								value: `${formatNumber(
									stateData.active
								)}\n(${(stateData.todayActives >= 0 ? '+' : '-') +
									String(Math.abs(stateData.todayActives)).replace(
										/(.)(?=(\d{3})+$)/g,
										'$1,'
									)})`,
								inline: true
							},
							{
								name: 'Tests',
								value: `${formatNumber(
									stateData.tests
								)}\n(${(stateData.todayTests >= 0 ? '+' : '-') +
									String(Math.abs(stateData.todayTests)).replace(
										/(.)(?=(\d{3})+$)/g,
										'$1,'
									)})`,
								inline: true
							},
							{
								name: 'Infection Rate',
								value: `${(stateData.casesPerOneMillion / 10000).toFixed(4)} %`,
								inline: true
							},
							{
								name: 'Last Updated',
								value: moment(stateData.updated).fromNow(),
								inline: true
							}
						)
						.setTimestamp()
						.setFooter(
							message.author.tag,
							message.author.avatarURL({
								dynamic: true,
								format: 'jpg',
								size: 2048
							})
						);

					msg.channel.send(covid19ST);
				} catch (e) {
					client.errI(`에러: ${e}`, msg.channel);
					client.errI(
						`명령어: ${cmd}\n에러: ${e}`,
						client.channels.cache.get(client.log.error)
					);
					return;
				}
			} else {
				try {
					let countryA = args[0];
					var cdataC = await track.countries({ country: countryA });
					var yesterdaycdataC = await novelCovid.yesterday.countries({
						country: countryA
					});

					if (!cdataC.population) {
						msg.lineReply('ㄱ...그게 뭐누!!\n국가 이름/코드를 넣어줘!!');
						return;
					}

					if (cdataC.message || yesterdaycdataC.message)
						return await message.channel.send(
							cdataC.message || yesterdaycdataC.message
						);
					cdataC.todayActives = cdataC.active - yesterdaycdataC.active;
					cdataC.todayRecovereds = cdataC.recovered - yesterdaycdataC.recovered;
					cdataC.todayTests = cdataC.tests - yesterdaycdataC.tests;

					let covid19C = new Discord.MessageEmbed()
						//.setTitle(`Covid 19: ${cdataC.country}`)
						.setAuthor(`Covid 19: ${cdataC.country}`, cdataC.countryInfo.flag)
						.setColor(client.color.bot)
						.setDescription(`실제 수치와 미미한 차이가 있을 수 있습니다.`)
						.addFields(
							{
								name: 'Total Cases',
								value: cdataC.cases.toLocaleString(),
								inline: true
							},
							{
								name: 'Total Deaths',
								value: cdataC.deaths.toLocaleString(),
								inline: true
							},
							{
								name: 'Total Recovered',
								value: cdataC.recovered.toLocaleString(),
								inline: true
							},
							{
								name: "Today's Cases",
								value: cdataC.todayCases.toLocaleString(),
								inline: true
							},
							{
								name: "Today's Deaths",
								value: cdataC.todayDeaths.toLocaleString(),
								inline: true
							},
							{
								name: 'Active Cases',
								value: cdataC.active.toLocaleString(),
								inline: true
							},
							{
								name: 'Tests',
								value: `${formatNumber(cdataC.tests)}\n(${(cdataC.todayTests >=
								0
									? '+'
									: '-') +
									String(Math.abs(cdataC.todayTests)).replace(
										/(.)(?=(\d{3})+$)/g,
										'$1,'
									)})`,
								inline: true
							},
							{
								name: 'Infection Rate',
								value: `${(cdataC.casesPerOneMillion / 10000).toFixed(4)} %`,
								inline: true
							},
							{
								name: 'Recovery Rate',
								value: `${((cdataC.recovered / cdataC.cases) * 100).toFixed(
									4
								)} %`,
								inline: true
							},
							{
								name: 'Population',
								value: formatNumber(cdataC.population),
								inline: true
							},
							{
								name: 'Last Updated',
								value: moment(cdataC.updated).fromNow(),
								inline: true
							}
						)
						.setTimestamp()
						.setFooter(
							message.author.tag,
							message.author.avatarURL({
								dynamic: true,
								format: 'jpg',
								size: 2048
							})
						);

					msg.channel.send(covid19C);
					return;
				} catch (e) {
					client.errI(`에러: ${e}`, msg.channel);
					client.errI(
						`명령어: ${cmd}\n에러: ${e}`,
						client.channels.cache.get(client.log.error)
					);
					return;
				}
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
