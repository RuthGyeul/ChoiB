const Discord = require('discord.js');
const moment = require('moment');
const client = new Discord.Client();

module.exports = {
	name: 'guild',
	aliases: ['GInfo', 'gi', '서버', '서버정보', 'server'],
	category: 'Info',
	description: 'Show guild information',
	utilisation: '{prefix}guild',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			const guild = msg.guild.id;
			const serverI = new Discord.MessageEmbed()
				.setTitle(`서버 정보: ${msg.guild.name}`)
				.setColor('#00EBF4')
				.setThumbnail(
					`https://cdn.discordapp.com/icons/${msg.guild.id}/${msg.guild.icon}`
				)
				.setDescription(`SID: ${msg.guild.id}\nCID: ${msg.channel.id}`)
				.addFields(
					{
						name: `👑 서버장`,
						value: `${msg.guild.owner || '난 모르겠는데?'}`,
						//msg.guild.ownerID-서버장ID
						inline: true
					},
					{
						name: `💕 멤버 수`,
						value: `총 ${msg.guild.memberCount}명`,
						inline: true
					},
					{
						name: `🗺 위치`,
						value: `${msg.guild.region}`,
						inline: true
					},
					{
						name: `⏰ 서버가 만들어진 시각 (UTC)`,
						value: `${moment
							.utc(msg.guild.createdAt)
							.format('YYYY년 MM월 DD일 HH:mm:ss')}`,
						inline: true
					},
					{
						name: `⏰ 내가 서버에 입장한 시각 (UTC)`,
						value: `${moment
							.utc(msg.member.joinedAt)
							.format('YYYY년 MM월 DD일 HH:mm:ss')}`,
						inline: true
					}
				)
				.setTimestamp()
				.setFooter(
					msg.author.tag,
					msg.author.avatarURL({ dynamic: true, format: 'jpg', size: 2048 })
				);

			msg.channel.send(serverI);
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
