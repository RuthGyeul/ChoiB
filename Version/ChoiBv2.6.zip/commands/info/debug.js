const Discord = require('discord.js');
const prettyMilliseconds = require('pretty-ms');
const client = new Discord.Client();

module.exports = {
	name: 'debug',
	aliases: ['debug', '최빈이', 'choib'],
	category: 'Info',
	description: 'ChoiB rolls once every 20 seconds!',
	utilisation: '{prefix}debug',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			const upt = client.uptime;
			const choibc = Number((upt / 20000).toFixed(1));
			const choibtmi = new Discord.MessageEmbed()
				.setTitle('ChoiB is still rolling!')
				.setURL('https://choib.rutheon.repl.co')
				.setColor('#00EBF4')
				.setDescription(`현재 최빈이는 **${choibc}** 번째 굴러가고 있습니다..`)
				.setFooter(
					message.author.tag,
					message.author.avatarURL({ dynamic: true, format: 'jpg', size: 2048 })
				)
				.setTimestamp();

			msg.channel.send(choibtmi);
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
