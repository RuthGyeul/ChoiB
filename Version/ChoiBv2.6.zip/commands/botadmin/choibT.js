const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'choibT',
	aliases: ['최빈정복'],
	category: 'BotAdmin',
	description: 'Undefined',
	utilisation: '{prefix}choibT <type>',

	execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;
		try {
			const sId = msg.guild.id;
			const chId = msg.channel.id;

			if (!msg.author.id == client.admin.author) return;

			if (!args[0]) {
				msg.channel.messages.fetch({ limit: 1 }).then(messages => {
					msg.channel.bulkDelete(messages);
				});

				msg.channel.send(`이제 이 채널은 제껍니다. 제가 마음대로 할 수 있죠.`);
			} else {
				const cmtype = args[0];

				if (cmtype == 'ANN') {
					const chbAnn = new Discord.MessageEmbed()
						.setTitle('디스코드 이용 수칙')
						.setURL('https://open.kakao.com/o/g47S996b')
						.setColor('#FFF539')
						.setDescription(`대부분의 디코 수칙은 옾챗방의 규정과 동일합니다.`)
						.addField(
							'1. 공지 채널 알림 설정',
							'왠만하면 공지 채널의 알림은 켜주세요!',
							false
						)
						.addField(
							'2. 디코 닉네임',
							'디코 닉넴은 기존 사용하던 닉넴을 반드시 포함하여 주세요!!',
							false
						)
						.addField(
							'3. 채널의 주제',
							'각 채널 마다 다른 목적이 있습니다. \n채널 설명을 읽어주세요!',
							false
						)
						.addField(
							'4. 디코봇 사용',
							'디코 봇은 사용후 나갈때 꼭 내보내주세요!',
							false
						)
						.addField(
							'5. 전체 멘션',
							'@here, @everyone과 같은 전체 멘션은 사용하지 마세요. \n(관리진 전체 긴급 호출 제외)',
							false
						)
						.addField(
							'6. 수위 발언',
							'옾챗 공지와 동일하게 일정 수위 이상으로 판단되는 모든  행위는 경고/강퇴 대상입니다. \n수위 조절 해주세요. (방통위 기준, 15세 이하)',
							false
						)
						.addField(
							'7. 디코 내역 기록',
							'본 디코 서버는 @최빈이에 의해 메시지 수정/삭제 시 해당 로그가 유저 아이디와 함께 기록됩니다. \n언행 주의 및 디코 사용 수칙 잘 따라주세요!\n운영진 징계 목적 외 수정/삭제된 메시지 공유하지마세요.',
							false
						)
						.addField(
							'8. 디코 물갈',
							'옾챗 물갈과 연계하면 매달 15일 마다 물갈을 진행합니다.\n자세한 진행 내용은 물갈 당하신 분들에게 따로 안내드리고 있습니다.',
							false
						)
						.addField(
							'9. 옾챗 연계',
							'본 서버는 옾챗과 연계되어 있는 서버로 옾챗 공지 또한 적용이됩니다.\n옾챗 공지를 확인 안할시 생기는 모든 불이익은 본인에게 있음을 강력히 명시합니다.\n또한 본 디코 서버에 입장시 모든 공지를 이해한걸로 간주합니다.',
							false
						)
						.setImage(
							'https://blog.hmgjournal.com/images_n/contents/170719_cat01.png'
						);

					msg.channel.messages.fetch({ limit: 1 }).then(messages => {
						msg.channel.bulkDelete(messages);
					});

					msg.channel.send(chbAnn);
				}

				if (cmtype == 'ANN2') {
					const chbAnn2 = new Discord.MessageEmbed()
						.setTitle('디스코드 이용 수칙')
						.setURL('https://open.kakao.com/o/g8v6pr6c')
						.setColor(client.colors.bot)
						.setDescription(`대부분의 디코 수칙은 옾챗방의 규정과 동일합니다.`)
						.addField(
							'1. 공지 채널 알림 설정',
							'왠만하면 공지 채널의 알림은 켜주세요!',
							false
						)
						.addField(
							'2. 디코 닉네임',
							'디코 닉네임은 옾챗 닉네임을 반드시 포함하여 주세요!!',
							false
						)
						.addField(
							'3. 채널의 주제',
							'각 채널 마다 다른 목적이 있습니다. \n채널 주제를 지켜주세요!',
							false
						)
						.addField(
							'4. 디코봇 사용',
							'각 봇 명령어는 공지 채널 스크롤 하시면 나옵니다. \n음악봇은 사용후 나갈때 꼭 내보내주세요!',
							false
						)
						.addField(
							'5. 수위 관련',
							'수위 관련 대화는 오직 19금 채널, 아늑한 침대에서만 가능합니다.\n채널 엑세스 요청은 관리진에 문의 주세요',
							false
						)
						.addField(
							'6. 디코 & 옾챗',
							'디코에서 활동하는 만큼 옾챗에서도 활동 바랍니다! \n옾챗을 나가거나 강퇴 될시 디코에서도 강퇴 처리됩니다.',
							false
						)
						.addField(
							'7. 디코 내역 기록',
							'본 디코 서버는 @최빈이에 의해 메시지 수정/삭제 시 해당 로그가 유저 아이디와 함께 기록됩니다. \n언행 주의 및 디코 사용 수칙 잘 따라주세요!',
							false
						)
						.addField(
							'8. 궁금한 점/질문',
							'모든 질문과 신고 등은 관리진에 언제든지 물어봐 주세요!',
							false
						)
						.setImage(
							'https://blog.hmgjournal.com/images_n/contents/170719_cat01.png'
						);

					msg.channel.messages.fetch({ limit: 1 }).then(messages => {
						msg.channel.bulkDelete(messages);
					});

					msg.channel.send(chbAnn2);
				}

				if (cmtype == 'MSG') {
					msg.channel.messages.fetch({ limit: 1 }).then(messages => {
						msg.channel.bulkDelete(messages);
					});
					msg.channel.send('<:emoji_38:800660915158122497>');
				}
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
