const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'uid',
	aliases: ['유아이디', '원신아이디'],
	category: 'GenshinImpact',
	description: 'Show Genshin Imapact user UID list',
	utilisation: '{prefix}uid',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (msg.guild.id == '698355063915282432') {
				const uidL = new Discord.MessageEmbed()
					.setTitle(`Genshin Impact UID List`)
					.setColor('#00EBF4')
					.setDescription(`추가 요청은 체온이에게`)
					.addFields({
						name: 'Name\u279CUID',
						value:
							'체온\u279C606981387\n도우\u279C601274145\n챱살\u279C602252334\n레아\u279C603240893\n꼬꼬\u279C606744594\n설화\u279C610486957\n준형\u279C611205373\n헨리\u279C616509624\n낙지\u279C627841601\n도윤\u279C632355681\n준우\u279C633129880\n이안\u279C634445345\n참치\u279C634515778\n예린\u279C633203677'
					})
					.setTimestamp()
					.setFooter(
						message.author.tag,
						message.author.avatarURL({
							dynamic: true,
							format: 'jpg',
							size: 2048
						})
					);

				msg.channel.send(uidL);
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.logs.error)
			);
			return;
		}
	}
};
