const Discord = require('discord.js');
const { getTemp } = require('hangang');
const client = new Discord.Client();

module.exports = {
	name: '한강물',
	aliases: ['한강', '한강온도', '한강물온도', 'hk'],
	category: 'Fun',
	description: 'Show Han',
	utilisation: '{prefix}한강물',

	async execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			const htp = await getTemp();
			const hgmsg = [
				'참 입수하기 좋은 온도죠?',
				'한 번 담궈 보실?',
				'어때요? 들어가실?',
				'한 번 뛰어 들어가는 것도 나쁘지 않겠어요!',
				'정말 뛰어들기 딱이네요~!',
				'인생은 한 방! 입수각~!!',
				'당연히 들어가실꺼죠?',
				'안들어가시고 뭐하세요?',
				'얼른 입수해요! 더 추워지기 전에!'
			];
			const hg1 = [
				'오우.. 얼어 뒤지겠네.',
				'옹.. 설마 들어갈꺼에요?',
				'들어갈 생각은 아니죠?',
				'따뜻해질 때 까지 기다려요!',
				'너무 추운데? 입수는 미루도록해요.',
				'입수는 미루는 걸로!'
			]; //얼어
			const hg2 = [
				'얼른 입수해요! 더 추워지기 전에!',
				'한 번 뛰어 들어가는 것도 나쁘지 않겠어요!',
				'시원할거 같아요! 입수!!',
				'시원하지 않을까요?',
				'얼른 들어가요! 시원하겠다~',
				'오~ 은근 괜찮은 온도에요! 입수!!',
				'어때요? 담궈 보실?'
			]; //추워
			const hg3 = [
				'안들어가시고 뭐하세요?',
				'인생은 한 방! 입수각~!!',
				'정말 뛰어들기 딱이네요~!',
				'나쁘지 않은 온도에요. 입수각!',
				'완전 입수각인데?',
				'안들어가고 뭐해요!!',
				'지금 안들어가면 후회하실꺼에요!',
				'어때요? 들어가실?'
			]; //적당
			const hg4 = [
				'참 입수하기 좋은 온도죠?',
				'우왕 정말 따뜻하겠네요!',
				'엄청 따뜻한데 이걸 안들어간다고?',
				'입수각이네요! 자, 얼른 뛰어요!',
				'왜 입수 안해??',
				'언제 입수해???'
			]; //따뜻
			const hg5 = [
				'오 얼어죽진 않겠어요!',
				'뭐해요? 안들어가?',
				'빨리 안들어가고 뭐해요?',
				'완벽하네요! 얼른 들어가요!!',
				'모든게 완벽해요! 입수!!'
			]; //더워

			/*for (var n = 0; n < hgmsg.length; n++) {
			let r = Math.floor(Math.random() * hgmsg.length);
			msg.lineReply(
				`지금 한강물 온도는 ` +
					'```' +
					`${htp}°C` +
					'```' +
					`인데..` +
					`\n${hgmsg[r]}`
			);
			return;
		}*/

			//starthtp
			//역대 한강 온도: -16 ~ 36
			if (htp <= 4.9) {
				//얼어
				for (var n = 0; n < hg1.length; n++) {
					let r1 = Math.floor(Math.random() * hg1.length);
					msg.lineReply(
						`지금 한강물 온도는 ` +
							'``' +
							`${htp}°C` +
							'``' +
							`인데..` +
							`\n${hg1[r1]}`
					);
					return;
				}
			} else if (htp >= 5 && htp <= 12.9) {
				//추워
				for (var n = 0; n < hg2.length; n++) {
					let r2 = Math.floor(Math.random() * hg2.length);
					msg.lineReply(
						`지금 한강물 온도는 ` +
							'``' +
							`${htp}°C` +
							'``' +
							`인데..` +
							`\n${hg2[r2]}`
					);
					return;
				}
			} else if (htp >= 13 && htp <= 17.9) {
				//적당
				for (var n = 0; n < hg3.length; n++) {
					let r3 = Math.floor(Math.random() * hg3.length);
					msg.lineReply(
						`지금 한강물 온도는 ` +
							'``' +
							`${htp}°C` +
							'``' +
							`인데..` +
							`\n${hg3[r3]}`
					);
					return;
				}
			} else if (htp >= 18 && htp <= 26.9) {
				//따뜻
				for (var n = 0; n < hg4.length; n++) {
					let r4 = Math.floor(Math.random() * hg4.length);
					msg.lineReply(
						`지금 한강물 온도는 ` +
							'``' +
							`${htp}°C` +
							'``' +
							`인데..` +
							`\n${hg4[r4]}`
					);
					return;
				}
			} else if (htp >= 27) {
				//더워
				for (var n = 0; n < hg5.length; n++) {
					let r5 = Math.floor(Math.random() * hg5.length);
					msg.lineReply(
						`지금 한강물 온도는 ` +
							'``' +
							`${htp}°C` +
							'``' +
							`인데..` +
							`\n${hg5[r5]}`
					);
					return;
				}
			} //endhtp
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
