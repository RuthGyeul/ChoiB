const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: '동전던지기',
	aliases: ['코인', '동전', '코인던지기'],
	category: 'Fun',
	description: 'Flip the coin',
	utilisation: '{prefix}동전던지기',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (Math.floor(Math.random() * 15) === 0) {
				msg.lineReply(
					'\n' +
						(Math.floor(Math.random() * 2) ? '엥' : '헐') +
						' 동전이 시야를 벋어났어..\n살살 좀 던져..'
				);
			} else {
				msg.lineReply(
					'\n' +
						(Math.floor(Math.random() * 2) ? '어? ' : '우왕! ') +
						(Math.floor(Math.random() * 2) ? '앞면' : '뒷면') +
						'이 나왔어!'
				);
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
