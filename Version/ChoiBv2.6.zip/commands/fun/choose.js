const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: '골라',
	aliases: ['선택', 'ch'],
	category: 'Fun',
	description: 'Choose one from the options',
	utilisation: '{prefix}골라 <options>',

	execute(client, message, args) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (!args[0]) {
				msg.lineReply('나더러 뭐 어쩌라는거지?...');
			} else {
				var a = cmd.trim().substring(4);
				var b = a.split(' ');

				if (b.length == 1) {
					msg.lineReply('이거 혹시 그건가? 답정너?');
				} else if (b[0] == b[Number(b.length)]) {
					msg.lineReply('이거 혹시 그건가? 답정너?');
				} else {
					if (Math.floor(Math.random() * 15) === 0) {
						if (Math.floor(Math.random() * 2) === 0) {
							msg.lineReply('움... 내가 골라도 짜피 답정너잖아!!');
						} else {
							msg.lineReply('움.. 답해주기 무척이나 귀찮은걸?');
						}
					} else {
						var n = Math.floor(Math.random() * b.length);
						msg.lineReply('내 선택은 『 ' + b[n] + ' 』 !!');
					}
				}
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};

//b[b.length] -> undefined
