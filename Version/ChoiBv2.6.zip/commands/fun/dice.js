const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'dice',
	aliases: ['d', '주사위'],
	category: 'Fun',
	description: 'Roll the dice',
	utilisation: '{prefix}dice',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			let dice = Math.floor(Math.random() * (6 - 1)) + 1;

			msg.lineReply('\n데굴데굴...  『 ' + dice + ' 』 !!');
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
