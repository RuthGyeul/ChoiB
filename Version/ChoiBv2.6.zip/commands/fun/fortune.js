const Discord = require('discord.js');
const fs = require('fs');
const client = new Discord.Client();
const randomColor = require('randomcolor');

const ftdb = './fileDB/fortune.json';
const ftdata = fs.readFileSync(ftdb);
const fortuneW = JSON.parse(ftdata);

module.exports = {
	name: 'fortune',
	aliases: ['fc', '운세', '포춘쿠키'],
	category: 'Fun',
	description: 'Show fortune of today',
	utilisation: '{prefix}fortune',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			var date = new Date();
			var y = date.getFullYear();
			var m = date.getMonth() + 1;
			var d = date.getDate();

			var wd = fortuneW[Math.floor(Math.random() * fortuneW.length)];
			var color = randomColor();

			const embed = new Discord.MessageEmbed()
				.setTitle(`🔮 오늘의 포춘쿠키`)
				.setColor(color)
				.setDescription('```\n' + wd + '\n```')
				.setTimestamp()
				.setFooter(
					message.author.tag,
					message.author.avatarURL({
						dynamic: true,
						format: 'jpg',
						size: 2048
					})
				);

			msg.channel.send(embed);
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
