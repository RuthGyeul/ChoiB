const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: '어몽어스',
	aliases: ['어몽어스', '임포스터', 'imposter', 'amongus', '임포'],
	category: 'Fun',
	description: 'Distinguish whether you are an imposter or not',
	utilisation: '{prefix}어몽어스',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			const imp = msg.guild.member(msg.author).nickname || msg.author.username;

			if (Math.floor(Math.random() * 8) == 0) {
				console.log(`IP-{ ${msg.author.tag} } 임포스터 당첨!`);
				msg.lineReply(
					'.      　。　　　　•　    　ﾟ　　。\n　　.　　　.　　　  　　.　　　　　。　　   。　.\n 　.　　      。　        ඞ   。　    .    •\n • **' +
						imp +
						'**(은)는 임포스터였습니다. 　 。　.\n　 　　。　　　　　　ﾟ　　　.　　　　　.\n,　　　　.　 .　　       .               。'
				);
				msg.lineReply(`5초 후 강퇴를 진행합니다.`).then(msg => {
					setTimeout(function() {
						msg.edit('4초 후 강퇴를 진행합니다.');
					}, 1000);
					setTimeout(function() {
						msg.edit('3초 후 강퇴를 진행합니다.');
					}, 2000);
					setTimeout(function() {
						msg.edit('2초 후 강퇴를 진행합니다.');
					}, 3000);
					setTimeout(function() {
						msg.edit('1초 후 강퇴를 진행합니다.');
					}, 4000);
					setTimeout(function() {
						msg.edit('0초 후 강퇴를 진행합니다.');
					}, 5000);
					setTimeout(function() {
						msg.edit('에러로 인해 강퇴 실패! 때잉 쯧~!');
					}, 15000);
					setTimeout(function() {
						msg.edit('***삭제된 메시지***');
						//msg.delete();
					}, 20000);
				});
			} else {
				msg.lineReply(
					'.      　。　　　　•　    　ﾟ　　。\n　　.　　　.　　　  　　.　　　　　。　　   。　.\n 　.　　      。　        ඞ   。　    .    •\n • **' +
						imp +
						'**(은)는 임포스터가 아니였습니다. 　 。　.\n　 　　。　　　　　　ﾟ　　　.　　　　　.\n,　　　　.　 .　　       .               。'
				);
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
