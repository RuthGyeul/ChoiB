const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'percentage',
	aliases: ['pr', '확률', '운세'],
	category: 'Fun',
	description: 'Pull number between 0~100',
	utilisation: '{prefix}percentage',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			let pr = Math.ceil(Math.random() * 101 * 1000) / 1000 - 1;

			msg.lineReply('『 ' + pr + '% 』 !!');
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
