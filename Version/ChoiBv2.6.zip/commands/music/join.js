const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'join',
	aliases: ['connect', 'j'],
	category: 'Music',
	description: 'Join voice channel',
	utilisation: '{prefix}join',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (!message.guild) return;
			if (!message.member.voice.channel) {
				msg.lineReply('?');
				return;
			}
			if (
				message.guild.me.voice.channel &&
				message.member.voice.channel.id !== message.guild.me.voice.channel.id
			) {
				msg.lineReply(
					`나와 내 친구들과의 유대는 절대 끊어 놓을 수 없어.\n그게 '약소크'니까.`
				);
				return;
			}

			if (message.member.voice.channel) {
				message.member.voice.channel.join();
				message.lineReply(
					`✅ | 당신이 외롭지 않게 최빈이가 당신과 함께 해줄게요!`
				);
			} else {
				message.lineReply(
					`⚠️ | 니가 먼저 음성 채널에 들어가 있어야 내가 어디로 갈지 알죠;;`
				);
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
