const Discord = require('discord.js');
const client = new Discord.Client();

module.exports = {
	name: 'leave',
	aliases: ['disconnect', 'dc', 'lv'],
	category: 'Music',
	description: 'Leave voice channel',
	utilisation: '{prefix}leave',

	execute(client, message) {
		const msg = message;
		const cmd = msg.content;
		try {
			if (!message.guild) return;
			if (!message.member.voice.channel) {
				msg.lineReply('?');
				return;
			}
			if (
				message.guild.me.voice.channel &&
				message.member.voice.channel.id !== message.guild.me.voice.channel.id
			) {
				msg.lineReply('?.. 니가? 감히 날?');
				return;
			}

			if (message.member.voice.channel) {
				if (Math.floor(Math.random() * 3) === 0) {
					message.member.voice.channel.leave();
					message.lineReply(
						`👋 | 흥! 날 버리다니.. 어디 한 번 나 없이 잘 버티나 보자!`
					);
				} else {
					message.lineReply(`🤨 | 절대 안나갈꺼야! 절. 대. 못. 나. 가.`);
				}
			} else {
				message.lineReply(
					`🙄 | 니가 먼저 음성 채널에 들어가 있어야 내가 들어가든 나가든 하죠;;`
				);
			}
		} catch (e) {
			client.errI(`에러: ${e}`, msg.channel);
			client.errI(
				`명령어: ${cmd}\n에러: ${e}`,
				client.channels.cache.get(client.log.error)
			);
			return;
		}
	}
};
